package com.example.demo.service;

import com.example.demo.entity.Student;
import org.springframework.stereotype.Service;

import java.util.List;

public interface studentService {
    public Student addStudents(Student stu);
    public List<Student> getStudents();
    public Student getStudentById(long id);
    public Student updateStudent(long id,Student stu);
    public boolean deleteStudentById(long id);
}
