package com.example.demo.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jdk.jfr.Timestamp;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name="Student_1")
@Getter
@Setter
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotBlank(message="Name can't be null")
    private String name;

    @NotBlank(message="Email can't be null")
    @Email(message="Not valid email")
    private String email;

    @NotNull(message="Age is required")
    @Min(value=5,message="Age should be greater then 5")
    private Integer age;

    private String phone;

    @NotEmpty(message="Address is required")
    private String address;

    private boolean active=true;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate(){
        createdAt=LocalDateTime.now();
        updatedAt=LocalDateTime.now();
    }
    @PreUpdate
    public void onUpdate(){
        updatedAt=LocalDateTime.now();
    }

}
