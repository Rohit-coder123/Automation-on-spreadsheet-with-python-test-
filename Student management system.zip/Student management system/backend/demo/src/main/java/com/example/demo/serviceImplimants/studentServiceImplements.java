package com.example.demo.serviceImplimants;

import com.example.demo.entity.Student;
import com.example.demo.exception.StudentNotFoundException;
import com.example.demo.repository.studentRepository;
import com.example.demo.service.studentService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class studentServiceImplements implements studentService {
    private final studentRepository sturep;
    public studentServiceImplements(studentRepository sturep){
        this.sturep=sturep;
    }

    @Override
    public Student addStudents(Student stu){
        return sturep.save(stu);
    }

    @Override
    public List<Student> getStudents(){
        return sturep.findByActiveTrue();
    }

    @Override
    public Student getStudentById(long id){
        Student student=sturep.findById(id) .orElseThrow(
                () -> new StudentNotFoundException("Student not found of id "+id)
        );
        if(!student.isActive()){
            throw new StudentNotFoundException("Student not found of id "+id);
        }
        return student;
    }

    @Override
    public Student updateStudent(long id,Student stu){
        Student current = sturep.findById(id) .orElseThrow(
                () -> new StudentNotFoundException("Student not found of id "+id)
        );
        if(!current.isActive()){
            throw new StudentNotFoundException("Student not found of id "+id);
        }
        current.setName(stu.getName());
        current.setEmail(stu.getEmail());
        current.setAge(stu.getAge());
        current.setPhone(stu.getPhone());
        current.setAddress(stu.getAddress());
        return sturep.save(current);
    }

    @Override
    public boolean deleteStudentById(long id){
        Student current =sturep.findById(id).orElseThrow(
                () -> new StudentNotFoundException("Student not found of id "+id)
        );
        if(!current.isActive()){
            throw new StudentNotFoundException("Student not found of id "+id);
        }
        current.setActive(false);
        sturep.save(current);

        return true;
    }
}
