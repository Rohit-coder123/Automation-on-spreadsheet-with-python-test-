package com.example.demo.controller;

import com.example.demo.entity.Student;
import com.example.demo.service.studentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/students")
public class StudentController {
     private final studentService stuserv;
     public StudentController(studentService stuserv){
         this.stuserv=stuserv;
     }
     @PostMapping("/add")
     public Student addStudent(
             @Valid @RequestBody Student stu
     ){
         return stuserv.addStudents(stu);
     }

     @GetMapping("/fetch")
     public List<Student> getStudent(){
         return stuserv.getStudents();
     }

     @GetMapping("/fetch/{id}")
     public Student getStudentById(
             @PathVariable long id
     ){
         return stuserv.getStudentById(id);
     }

     @PutMapping("/update/{id}")
     public Student updateStudentById(
             @Valid
             @PathVariable long id,
             @RequestBody Student stu
     ){
         return stuserv.updateStudent(id,stu);
     }

     @DeleteMapping("/delete/{id}")
     public boolean deleteById(
             @PathVariable long id
     ){
         return stuserv.deleteStudentById(id);
     }
}
