package com.example.demo.repository;

import com.example.demo.entity.Student;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface studentRepository extends JpaRepository<Student,Long> {
    List<Student> findByActiveTrue();
}
