import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-alert',
  imports: [],
  templateUrl: './alert.html',
  styleUrl: './alert.css',
})
export class Alert {
  @Input()
  message = ''; //Recieve message here

  @Input()
  type: 'success' | 'error' = 'success'; //Allowed values success and error , where default value is success
}
