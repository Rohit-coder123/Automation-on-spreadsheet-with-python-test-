import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  inject,
} from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Student } from '../../models/student/student';

@Component({
  selector: 'app-student-form',
  imports: [ReactiveFormsModule],
  standalone: true,
  templateUrl: './student-form.html',
  styleUrl: './student-form.css',
})
export class StudentForm implements OnChanges {
  private fb = inject(FormBuilder);

  studentForm = this.fb.group({
    name: ['', Validators.required],

    email: ['', [Validators.required, Validators.email]],

    age: ['', [Validators.required, Validators.min(18), Validators.max(100)]],

    phone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],

    address: ['', Validators.required],
  });

  @Output()
  formSubmit = new EventEmitter<any>();
  onSubmit() {
    if (this.studentForm.invalid) {
      this.studentForm.markAllAsTouched();
      return;
    }
    this.formSubmit.emit(this.studentForm.value);
  }

  get f() {
    return this.studentForm.controls;
  }
  // @Input(): used to make the communication between parent and child
  @Input() studentData!: Student;

  ngOnChanges(changes: SimpleChanges): void {
    if (this.studentData) {
      this.studentForm.patchValue({
        name: this.studentData.name,

        email: this.studentData.email,

        age: String(this.studentData.age),

        phone: this.studentData.phone,

        address: this.studentData.address,
      });
    }
  }
}
