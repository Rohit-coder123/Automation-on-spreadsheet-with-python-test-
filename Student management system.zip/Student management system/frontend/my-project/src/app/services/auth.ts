export interface User {
  username: String;
  password: String;
  role: 'ADMIN | STUDENT';
}
