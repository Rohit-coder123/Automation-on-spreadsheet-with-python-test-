export interface Student {
  id?: number;

  name: string;

  email: string;

  age: number;

  phone: string;

  address: string;

  createdAt?: string;

  updatedAt?: string;
}
