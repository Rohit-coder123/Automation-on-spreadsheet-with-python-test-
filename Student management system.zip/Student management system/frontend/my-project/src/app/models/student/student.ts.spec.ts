import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentTs } from './student.ts';

describe('StudentTs', () => {
  let component: StudentTs;
  let fixture: ComponentFixture<StudentTs>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StudentTs],
    }).compileComponents();

    fixture = TestBed.createComponent(StudentTs);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
