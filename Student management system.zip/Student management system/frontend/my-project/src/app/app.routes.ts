import { Routes } from '@angular/router';

import { Dashboard } from './pages/dashboard/dashboard';
import { StudentsList } from './pages/students-list/students-list';
import { AddStudent } from './pages/add-student/add-student';
import { EditStudent } from './pages/edit-student/edit-student';
import { StudentDetails } from './pages/student-details/student-details';
import { Login } from './pages/login/login';
import { AdminDashboard } from './pages/admin-dashboard/admin-dashboard';
import { StudentDashboard } from './pages/student-dashboard/student-dashboard';
import { Unauthorized } from './pages/unauthorized/unauthorized';

export const routes: Routes = [
  {
    path: '',
    component: Login,
  },
  {
    path: 'admin-dashboard',
    component: AdminDashboard,
  },

  {
    path: 'student-dashboard',
    component: StudentDashboard,
  },

  {
    path: 'unauthorized',
    component: Unauthorized,
  },
  {
    path: 'dashboard',
    component: Dashboard,
  },
  {
    path: 'students',
    component: StudentsList,
  },

  {
    path: 'students/add',
    component: AddStudent,
  },

  {
    path: 'students/edit/:id',
    component: EditStudent,
  },

  {
    path: 'students/:id',
    component: StudentDetails,
  },
];
