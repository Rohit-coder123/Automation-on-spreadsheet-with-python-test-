import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { inject } from '@angular/core';
import { StudentService } from '../../services/student';
import { Student } from '../../models/student/student';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-students-list',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './students-list.html',
  styleUrl: './students-list.css',
})
export class StudentsList {
  private router = inject(Router);

  private studentService = inject(StudentService);

  students: Student[] = [];

  constructor() {
    this.loadStudents();
  }

  loadStudents() {
    this.studentService.getStudents().subscribe({
      next: (data) => {
        console.log('Students received:', data);

        this.students = data;
        console.log('students', this.students);
      },

      error: (error) => {
        console.error('API Error:', error);
      },
    });
  }

  viewStudent(id: number) {
    this.router.navigate(['/students', id]);
  }

  editStudent(id: number) {
    this.router.navigate(['/students/edit', id]);
  }

  deleteStudent(id: number) {
    this.studentService.deleteStudent(id).subscribe({
      next: () => {
        this.loadStudents();
      },

      error: (error) => {
        console.error(error);
      },
    });
  }
}
