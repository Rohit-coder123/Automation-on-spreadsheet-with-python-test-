import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { StudentForm } from '../../components/student-form/student-form';
import { StudentService } from '../../services/student';
import { Student } from '../../models/student/student';
@Component({
  selector: 'app-add-student',
  standalone: true,
  imports: [StudentForm],
  templateUrl: './add-student.html',
  styleUrl: './add-student.css',
})
export class AddStudent {
  private studentService = inject(StudentService);

  private router = inject(Router);

  saveStudent(student: Student) {
    this.studentService.addStudent(student).subscribe({
      next: () => {
        this.router.navigate(['/students']);
      },

      error: (error) => {
        console.error(error);
      },
    });
  }
}
