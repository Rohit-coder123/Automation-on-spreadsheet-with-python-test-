import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentForm } from '../../components/student-form/student-form';
import { StudentService } from '../../services/student';
import { Student } from '../../models/student/student';

@Component({
  selector: 'app-edit-student',
  standalone: true,
  imports: [StudentForm],
  templateUrl: './edit-student.html',
  styleUrl: './edit-student.css',
})
export class EditStudent {
  private route = inject(ActivatedRoute);

  private router = inject(Router);

  private studentService = inject(StudentService);

  student!: Student;

  constructor() {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    this.studentService.getStudentById(id).subscribe({
      next: (data) => {
        this.student = data;
      },

      error: (error) => {
        console.error(error);
      },
    });
  }

  updateStudent(updatedStudent: any) {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    this.studentService
      .updateStudent(id, {
        id,
        ...updatedStudent,
      })
      .subscribe({
        next: () => {
          this.router.navigate(['/students']);
        },

        error: (error) => {
          console.error(error);
        },
      });
  }
}
