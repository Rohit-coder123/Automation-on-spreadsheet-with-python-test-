import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from '../../services/student';
import { Student } from '../../models/student/student';

@Component({
  selector: 'app-student-details',
  imports: [],
  standalone: true,
  templateUrl: './student-details.html',
  styleUrl: './student-details.css',
})
export class StudentDetails {
  private route = inject(ActivatedRoute);

  private studentService = inject(StudentService);

  student!: Student;

  constructor() {
    const id = Number(this.route.snapshot.paramMap.get('id'));

    this.studentService.getStudentById(id).subscribe({
      next: (data) => {
        this.student = data;
      },

      error: (error) => {
        console.error(error);
      },
    });
  }
}
